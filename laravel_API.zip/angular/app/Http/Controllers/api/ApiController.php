<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;

class ApiController extends Controller
{
    public function register(Request $request){
        $user_data['lname'] = $request['lname'];
        $user_data['fname'] = $request['fname'];
        $user_data['email'] = $request['email'];
        $user_data['contact'] = $request['contact'];
        $user_data['password'] = bcrypt($request['password']);

        $result = User::create($user_data);

        if($result){

            return response()->json('Employee Created Successfully');

        }else{

            return response()->json('Something Went Wrong.');

        }
    }

    public function get_user(Request $request){
        $user_data = User::orderBy('id','DESC')->get();

        return response()->json($user_data);
    }

    public function update_user(Request $request){

        $id = $request['id'];

        $user_data['lname'] = $request['lname'];
        $user_data['fname'] = $request['fname'];
        $user_data['email'] = $request['email'];
        $user_data['contact'] = $request['contact'];

        $result = User::where('id',$id)->update($user_data);

        if($result){

            return response()->json('Employee Updated Successfully');

        }else{

            return response()->json('Something Went Wrong.');

        }
    }

    public function delete_user(Request $request){
        $id = $request['id'];
        $user_data = User::where('id',$id)->delete();

        return response()->json('Employee Deleted Successfully');

    }

    public function get_user_details(Request $request){
        $id = $request['id'];

        $user_data = User::where('id',$id)->get();

        return response()->json($user_data);
    }
}
